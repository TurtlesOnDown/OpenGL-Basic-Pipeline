#include "Includes.h"

#include "Component.h"

Component::Component(COMPONENT_TYPE t):type(t) {

}

Component::~Component() {

}